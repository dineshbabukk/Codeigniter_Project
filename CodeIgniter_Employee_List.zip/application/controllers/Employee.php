<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Employee extends CI_Controller {
   /**
    * Get All Data from this method.
    *
    * @return Response
   */
   public function index()
   {
       $this->load->database();
       $this->db->limit(5, ($this->input->get("page",1) - 1) * 5);
       $query = $this->db->get("employee_list");
       $data['data'] = $query->result();
       $data['total'] = $this->db->count_all("employee_list");
       echo json_encode($data);
   }


   /**
    * Store Data from this method.
    *
    * @return Response
   */
   public function add()
   {
       $this->load->database();
       $insert = $this->input->post();
	   // echo "<pre>";
	   // print_r($insert); exit;
	   if(empty($insert['emp_name'])){
			echo json_encode('Insert Failed');
	   }
       $this->db->insert('employee_list', $insert);
       $id = $this->db->insert_id();
       $q = $this->db->get_where('employee_list', array('id' => $id));
       echo json_encode($q->row());
    }


   /**
    * Edit Data from this method.
    *
    * @return Response
   */
   public function edit($id)
   {
       $this->load->database();
       $q = $this->db->get_where('employee_list', array('id' => $id));
       echo json_encode($q->row());
   }


   /**
    * Update Data from this method.
    *
    * @return Response
   */
   public function update($id)
   {
       $this->load->database();
       $insert = $this->input->post();
	   /* echo "<pre>";
	   print_r($insert); exit; */
       $this->db->where('id', $id);
       $this->db->update('employee_list', $insert);
       $q = $this->db->get_where('employee_list', array('id' => $id));
       echo json_encode($insert);
    }


   /**
    * Delete Data from this method.
    *
    * @return Response
   */
   public function delete($id)
   {
       $this->load->database();
       $this->db->where('id', $id);
       $this->db->delete('employee_list');
       echo json_encode(['success'=>true]);
    }


}